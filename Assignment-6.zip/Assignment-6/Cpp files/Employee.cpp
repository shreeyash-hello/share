#include<iostream>
#include<cstring>
using namespace std;


class Employee
{
private:
    int empId, salary;
    char *eName;
public:
    Employee(){
        empId = 0;
        salary = 0;
        *eName = '\0';
    }

    Employee(int eID, int sal, const char* eNm){
        empId = eID;
        salary = sal;
        eName = new char[strlen(eNm)+1];
        strcpy(eName, eNm);
    }

    void displayEmp(){
        cout << "Employee ID: " << empId << endl;
        cout << "Employee Name: " << eName << endl;
        cout << "Employee salary: " << salary << endl;
    }

    int getEmpId(){
        return empId;
    }

    ~Employee(){
        delete[] eName;
    }
};

int  size = 100, count = 0;

void AcceptEmployee(Employee** arr, int size){
    int eId, sal;
    char nm[100];
    cout << "Enter Employee ID: ";
    cin >> eId;
    cout << "Enter Employee name: ";
    cin >> nm;
    cout << "Enter Employee salary: ";
    cin >> sal;
    arr[count] = new Employee(eId, sal, nm);
    count++;
}

void Display(Employee** arr, int count){
    for(int i = 0; i<count; i++){
        arr[i]->displayEmp();
    }
}

void SortEmp(Employee **ptrr, int size, int sort){
    for(int i=0;i<size-1;i++){
        for(int j=0;j<size-i-1;j++){
            if(sort == 0){
                if(ptrr[j]->getEmpId() > ptrr[j+1]->getEmpId()){
                    Employee *temp=ptrr[j];
                    ptrr[j]=ptrr[j+1];
                    ptrr[j+1]=temp;
                }
            }else if(sort == 1){
                {
                    if(ptrr[j]->getEmpId() < ptrr[j+1]->getEmpId()){
                        Employee *temp=ptrr[j];
                        ptrr[j]=ptrr[j+1];
                        ptrr[j+1]=temp;
                }
            }
            }else{
                cout << "Wrong choice entered!!" << endl;
            }
        }
    }
}



int main(){
    int n, choice, size = 100;
    Employee **s = new Employee*[size];

    do
    {
        cout<<"\n--- MENU ---";
        cout<<"\n1 Add Employee";
        cout<<"\n2 Display EMployee";
        cout<<"\n3 Sort Employee ";
        cout<<"\n4 Exit";
        cout<<"\nEnter choice: ";
        cin>>choice;
        switch (choice)
        {
        case 1:{
            AcceptEmployee(s, size);
            break;
        }
        case 2:{    
            Display(s, count);
            break;
        }
        case 3:{
            int n;
            cout << "Enter 1 for descending, 0 for ascending: ";
            cin >> n;
            SortEmp(s, count, n);
            Display(s, count);
            break;
        }
        case 4:
            cout << "Program exit!!" << endl;
            break;

        default:
            cout << "Invalid choice!!" << endl;
            break;
        }
        
    } while (choice != 4);

}
