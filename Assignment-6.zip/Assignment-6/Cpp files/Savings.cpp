#include "Savings.h"

int Savings::minBalance = 2000;
float Savings::interestRate = 0.04;

Savings::Savings()
{
    chequeBookNo = 589000;
}

void Savings::AcceptSavingsData()
{
    AcceptDetails();
    chequeBookNo++;
    cout << "Cheque Book Number: " << chequeBookNo << endl;
}

void Savings::Deposit()
{
    if (PinCheck())
    {
        int amt;
        cout << "Enter amount to deposit: ";
        cin >> amt;
        balance = balance + minBalance + amt;
    }
}

void Savings::Withdraw()
{
    if (PinCheck())
    {
        int amt;
        cout << "Enter amount to withdraw: ";
        cin >> amt;
        if (balance - amt >= minBalance){
            balance -= amt;
        }else{
            cout << "Minimum balance must remain " << minBalance << endl;
        }
    }
}

void Savings::Transact(){
    int choice;
    do{
        cout << "Choose from the following" << endl;
        cout << "1. Deposit \n2. Withdraw \n3. Display Balance \n4.Exit" << endl;
        cin >> choice;
        switch (choice)
        {
        case 1:
            Deposit();
            break;

        case 2:
            Withdraw();
            break;

        case 3:
            ShowBalance();
            break;

        case 4:
            cout << "Program exit!!" << endl;
            break;
        
        default:
            cout << "Invalid Choice!!" << endl;
            break;
        }
    }while(choice != 4);
}

void Savings::DisplayAccount()
{
    if (PinCheck())
    {
        DisplayBasic();
        cout << "Account Type: Savings" << endl;
        cout << "Interest Rate: " << interestRate * 100 << "%" << endl;
        cout << "Minimum Balance: " << minBalance << endl;
        cout << "Balance: " << balance << endl;
    }
}