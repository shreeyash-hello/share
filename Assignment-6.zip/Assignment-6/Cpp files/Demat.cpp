#include "Demat.h"

Demat::Demat() {}

void Demat::AcceptDematData()
{
    AcceptDetails();

    cout << "Enter Share Name: ";
    cin >> shareName;

    cout << "Enter number of shares: ";
    cin >> shares;

    cout << "Enter buy price: ";
    cin >> buyPrice;

    cout << "Enter sell price: ";
    cin >> sellPrice;
}

void Demat::DisplayAccount()
{
    if (PinCheck())
    {
        DisplayBasic();

        cout << "Account Type: Demat" << endl;
        cout << "Share Name: " << shareName << endl;
        cout << "Shares: " << shares << endl;
        cout << "Buy Price: " << buyPrice << endl;
        cout << "Sell Price: " << sellPrice << endl;
    }
}