#ifndef BANK_H
#define BANK_H

#include <iostream>
#include <string>
using namespace std;

class BankAccount
{
private:
    int AccNo;
    string fname,lname,email,mobile;
    int Pin;

protected:
    int balance;
    static int count;

public:
    BankAccount();
    void AcceptDetails();
    bool PinCheck();
    void DisplayBasic();
    virtual void DisplayAccount();
    int getAccount();
    void ShowBalance();
    ~BankAccount();
};

#endif