#include "Bank.h"

int BankAccount::count = 253000;

BankAccount::BankAccount()
{
    AccNo = ++count;
    balance = 0;
}

void BankAccount::AcceptDetails()
{
    cout << "Account Number: " << AccNo << endl;

    cout << "Enter First Name: ";
    cin >> fname;

    cout << "Enter Last Name: ";
    cin >> lname;

    do
    {
        cout << "Enter mobile number: ";
        cin >> mobile;
        if(mobile.length() != 10){
            cout << "Invalid mobile number!!" << endl;
        }
    } while (mobile.length() != 10);
    

    cout << "Enter Email: ";
    cin >> email;

    cout << "Set PIN: ";
    cin >> Pin;
}

bool BankAccount::PinCheck()
{
    int pincheck;

    cout << "Enter PIN: ";
    cin >> pincheck;

    return pincheck == Pin;
}

void BankAccount::DisplayBasic()
{
    cout << "Account No: " << AccNo << endl;
    cout << "Name: " << fname << " " << lname << endl;
    cout << "Mobile: " << mobile << endl;
    cout << "Email: " << email << endl;
}

void BankAccount::DisplayAccount()
{
    DisplayBasic();
}

int BankAccount::getAccount()
{
    return AccNo;
}

void BankAccount::ShowBalance(){
    if(PinCheck()){
        cout << "The current balance is: " << balance << endl;
    }else{
        cout << "Wrong Pin enetered, cannot show balance" << endl;
    }
}

BankAccount::~BankAccount() {}