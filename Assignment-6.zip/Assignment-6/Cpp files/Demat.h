#include "Bank.h"

class Demat : public BankAccount
{
private:
    string shareName;
    int shares;
    float buyPrice;
    float sellPrice;

public:
    Demat();
    void AcceptDematData();
    void DisplayAccount();
};