#include "Current.h"

int Current::minBalance = 1000;
float Current::interestRate = 0.01;

Current::Current()
{
    transactionsPerDay = 0;
}

void Current::AcceptCurrentData()
{
    AcceptDetails();
}

void Current::Deposit()
{
    if (PinCheck())
    {
        int amt;
        cout << "Enter amount to deposit: ";
        cin >> amt;
        balance = balance + minBalance + amt;
        transactionsPerDay += 1;
    }
}

void Current::Withdraw()
{
    if (PinCheck())
    {
        int amt;

        cout << "Enter amount to withdraw: ";
        cin >> amt;

        if (balance - amt >= minBalance){
            balance -= amt;
        }
        else{
            cout << "Withdraw not allowed!!" << endl;
            cout << "Minimum balance must remain " << minBalance << endl;
    
        }    
        transactionsPerDay += 1;
    }
}

void Current::Transact(){
    int choice;
    do{
        cout << "Choose from the following" << endl;
        cout << "1. Deposit \n2. Withdraw \n3. Display Balance \n4.Exit" << endl;
        cin >> choice;
        switch (choice)
        {
        case 1:
            Deposit();
            break;

        case 2:
            Withdraw();
            break;

        case 3:
            ShowBalance();
            break;

        case 4:
            cout << "Program exit!!" << endl;
            break;
        
        default:
            cout << "Invalid Choice!!" << endl;
            break;
        }
    }while(choice != 4);
}

void Current::DisplayAccount()
{
    if (PinCheck())
    {
        DisplayBasic();
        cout << "Account Type: Current" << endl;
        cout << "Transactions Per Day: " << transactionsPerDay << endl;
        cout << "Interest Rate: " << interestRate * 100 << "%" << endl;
    }
}