#include <iostream>
#include "Savings.h"
#include "Current.h"
#include "Demat.h"

using namespace std;

int main()
{
    BankAccount *acc[100];
    int count = 0;
    int choice;

    do
    {
        cout << "\n1 Add Savings Account\n";
        cout << "2 Add Current Account\n";
        cout << "3 Add Demat Account\n";
        cout << "4 Display Account\n";
        cout << "5 Deposit or withdraw from Current Account\n";
        cout << "6 Deposit or withdraw from Savings Account\n";
        cout << "7 Exit\n Enter Choice : ";

        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            Savings *s = new Savings();
            s->AcceptSavingsData();
            acc[count] = s;
            count++;
            break;
        }

        case 2:
        {
            Current *c = new Current();
            c->AcceptCurrentData();
            acc[count] = c;
            count++;
            break;
        }

        case 3:
        {
            Demat *d = new Demat();
            d->AcceptDematData();
            acc[count++] = d;
            break;
        }

        case 4:
        {
            if(count !=0 ){
                int ac;
                cout << "Enter account number: ";
                cin >> ac;
                for (int i = 0; i < count; i++)
                {
                    if (acc[i]->getAccount() == ac)
                    {
                        acc[i]->DisplayAccount();
                        break;
                    }
                }
            }else{
                cout << "Add account first" << endl;
                break;
            }
        }

        case 5:
        {
            int ac, loc = -1;
            cout << "Enter account number: ";
            cin >> ac;
            for (int i = 0; i < count; i++)
            {
                if (acc[i]->getAccount() == ac)
                {
                    loc = i;
                    acc[i]->DisplayAccount();
                    break;
                }
            }

            if(loc == -1)
            {
                cout << "Account not found" << endl;
                break;
            }

            Current* s = dynamic_cast<Current*>(acc[loc]);
            if(s != nullptr)
            {
                s->Transact();
            }
            break;
        }

        case 6:
        {
        {
            int ac, loc;
            cout << "Enter account number: ";
            cin >> ac;
            for (int i = 0; i < count; i++)
            {
                if (acc[i]->getAccount() == ac)
                {
                    loc = i;
                    acc[i]->DisplayAccount();
                }
            }

            Savings* s = dynamic_cast<Savings*>(acc[loc]);
            if(s != nullptr)
            {
                s->Transact();
            }
        } 
        }

        case 7:
            cout << "Program exit!!" << endl;
            break;

        default:
            cout << "Invalid choice!!" << endl;
        }

    } while (choice != 7);

    return 0;
}