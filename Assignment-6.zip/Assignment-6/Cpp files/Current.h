#include "Bank.h"

class Current : public BankAccount
{
private:
    int transactionsPerDay;
    static int minBalance;
    static float interestRate;

public:
    Current();
    void AcceptCurrentData();
    void Deposit();
    void Withdraw();
    void Transact();
    void DisplayAccount();
};
