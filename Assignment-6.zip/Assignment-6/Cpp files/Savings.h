#include "Bank.h"

class Savings : public BankAccount
{
private:
    int chequeBookNo;
    static int minBalance;
    static float interestRate;

public:
    Savings();
    void AcceptSavingsData();
    void Deposit();
    void Withdraw();
    void Transact();
    void DisplayAccount();
    ~Savings();
};
