#include <iostream>
#include <string>
#include "Vehicle.h"
#include "Bike.h"
using namespace std;

Bike::Bike():Vehicle(){
    engine = " ";
}

Bike::Bike(string regNo, string model, string manufac, 
    int year, string eng):Vehicle(regNo,  model,  manufac,  year){
    engine = eng;
}

void Bike::DisplayInfo(){
        cout << formatDisplay()
            <<", EngineCapacity: " << engine << endl;
}
Bike::~Bike(){}