#include <fstream>

void SaveToFile(Vehicle* v[], int count) {
    ofstream outFile("vehicles.dat", ios::binary | ios::trunc);
    if (!outFile) {
        cout << "Error opening file for writing!" << endl;
        return;
    }

    for (int i = 0; i < count; i++) {
        // We write a "type ID" first so we know what to recreate later
        // 1 for Car, 2 for Bike (assuming your logic)
        int type = (dynamic_cast<Car*>(v[i])) ? 1 : 2;
        outFile.write(reinterpret_cast<char*>(&type), sizeof(type));
        
        // Use a method in your class to write specific data
        v[i]->writeData(outFile); 
    }
    outFile.close();
    cout << "Data saved successfully!" << endl;
}

void ReadFromFile(Vehicle* v[], int &count) {
    ifstream inFile("vehicles.dat", ios::binary);
    if (!inFile) return;

    count = 0;
    int type;
    while (inFile.read(reinterpret_cast<char*>(&type), sizeof(type))) {
        if (type == 1) {
            v[count] = new Car();
        } else {
            v[count] = new Bike();
        }
        v[count]->readData(inFile);
        count++;
    }
    inFile.close();
}

virtual void writeData(ofstream &out) {
    // Helper to write strings
    int len = regNo.length();
    out.write(reinterpret_cast<char*>(&len), sizeof(len));
    out.write(regNo.c_str(), len);
    
    out.write(reinterpret_cast<char*>(&year), sizeof(year));
    // ... repeat for other members
}

virtual void readData(ifstream &in) {
    int len;
    in.read(reinterpret_cast<char*>(&len), sizeof(len));
    regNo.resize(len);
    in.read(&regNo[0], len);
    
    in.read(reinterpret_cast<char*>(&year), sizeof(year));
}

virtual void writeData(ofstream &out) {
    // Helper to write a string: Write length first, then the characters
    size_t len = registration.size();
    out.write(reinterpret_cast<char*>(&len), sizeof(len));
    out.write(registration.c_str(), len);

    len = model.size();
    out.write(reinterpret_cast<char*>(&len), sizeof(len));
    out.write(model.c_str(), len);

    len = manufacturer.size();
    out.write(reinterpret_cast<char*>(&len), sizeof(len));
    out.write(manufacturer.c_str(), len);

    out.write(reinterpret_cast<char*>(&year), sizeof(year));
}

virtual void readData(ifstream &in) {
    size_t len;
    
    in.read(reinterpret_cast<char*>(&len), sizeof(len));
    registration.resize(len);
    in.read(&registration[0], len);

    in.read(reinterpret_cast<char*>(&len), sizeof(len));
    model.resize(len);
    in.read(&model[0], len);

    in.read(reinterpret_cast<char*>(&len), sizeof(len));
    manufacturer.resize(len);
    in.read(&manufacturer[0], len);

    in.read(reinterpret_cast<char*>(&year), sizeof(year));
}

void writeData(ofstream &out) override {
    Vehicle::writeData(out); // Save common data
    size_t len = fuelType.size();
    out.write(reinterpret_cast<char*>(&len), sizeof(len));
    out.write(fuelType.c_str(), len);
}

void readData(ifstream &in) override {
    Vehicle::readData(in); // Read common data
    size_t len;
    in.read(reinterpret_cast<char*>(&len), sizeof(len));
    fuelType.resize(len);
    in.read(&fuelType[0], len);
}

void writeData(ofstream &out) override {
    Vehicle::writeData(out); 
    size_t len = engineCapacity.size();
    out.write(reinterpret_cast<char*>(&len), sizeof(len));
    out.write(engineCapacity.c_str(), len);
}

void readData(ifstream &in) override {
    Vehicle::readData(in);
    size_t len;
    in.read(reinterpret_cast<char*>(&len), sizeof(len));
    engineCapacity.resize(len);
    in.read(&engineCapacity[0], len);
}

ofstream outFile("garage.dat", ios::binary);
for (int i = 0; i < count; i++) {
    int type = (typeid(*v[i]) == typeid(Car)) ? 1 : 2;
    outFile.write(reinterpret_cast<char*>(&type), sizeof(type));
    v[i]->writeData(outFile);
}
outFile.close();

ifstream inFile("garage.dat", ios::binary);
int type;
while (inFile.read(reinterpret_cast<char*>(&type), sizeof(type))) {
    if (type == 1) v[count] = new Car();
    else v[count] = new Bike();
    
    v[count]->readData(inFile);
    count++;
}
inFile.close();