#include <iostream>
#include <fstream>
#include <string>
#include "Vehicle.h"
#include "Car.h"
using namespace std;

Car::Car():Vehicle(){
    FuelType = " ";
}

Car::Car(string regNo, string model, string manufac, 
    int year, string fuel):Vehicle(regNo,  model,  manufac,  year){
    FuelType = fuel;
}

void Car::DisplayInfo(){
    cout << formatDisplay()
        <<", FuelType: "<< FuelType <<endl;
        
}


Car::~Car(){}