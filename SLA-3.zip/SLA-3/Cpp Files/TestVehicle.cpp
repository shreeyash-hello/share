#include <iostream>
#include <string>
#include <cstring>
#include <ctime>
#include "Vehicle.h"
#include "Bike.h"
#include "Car.h"
using namespace std;

template <typename T>
bool validateYear(T year)
{
    time_t t = time(0);
    tm* now = localtime(&t);
    int currentYear = now->tm_year + 1900;

    return (year >= 2000 && year <= currentYear);
}

int count = 0;

void AcceptData(Vehicle *v[], int n){
    string reg, model, manufac, vehicle;
    int year;
    bool check = false;

    do
    {   try{
            cout << "Enter Registration number: ";
            cin.ignore();
            getline(cin, reg);
            if(reg == ""){
                check = true;
                throw "Registration number cannot be empty";
            }
            else{
                check = false;
            }
        }catch(const char* e){
            cout << e << endl;
        }
    } while (check);

    cout << "Enter Model name: ";
    cin >> model;

    cout << "Enter Manufacturer: ";
    cin >> manufac;

    check = false;

    do
    {
        try{
            cout << "Enter year: ";
            cin >> year;
            if(!validateYear(year)){
                check = true;
                throw "Invalid year";
            }else{
                check = false;
            }
        }catch(const char* e){
            cout << e << endl;
        }
    } while (check);

    if (n == 1){
        cout << "Enter Fuel Type: ";
        cin >> vehicle;
        v[count] = new Car(reg, model, manufac, year, vehicle);
        count++;
    }else{
        cout << "Enter Engine Capacity: ";
        cin >> vehicle;
        v[count] = new Bike(reg, model, manufac, year, vehicle);
        count++;
    }
}


int main(){
    int choice;
    Vehicle* v[100];
    do
    {
        cout << "1. Register Car \n2. Register Bike \n3. Display vehicles \n4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice)
        {
        case 1:
            AcceptData(v, 1);
            break;
        
        case 2:
            AcceptData(v, 0);
            break;

        case 3:
            for(int i = 0; i<count; i++){
                v[i]->DisplayInfo();
                if(count == i+1){
                    cout << "---------------------------------------------------------------------------------------" << endl;
                    cout << "Total Vehicles stored:" << count << endl;
                }
            }
            break;

        case 4:
            cout << "Program Exit!!";
            break;

        default:
            cout << "Invalid choice!!";
            break;
        }
    } while (choice != 4);
    return 0;
}
