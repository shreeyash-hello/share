#include <iostream>
#include <string>
#include "Vehicle.h"

using namespace std;

class Car: public Vehicle
{
private:
    string FuelType;
public:
    Car();
    Car(string regNo, string model, string manufac, 
    int year, string fuel);
    void DisplayInfo();
    ~Car();
};