#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <string>
using namespace std;

class Vehicle
{
protected:
    string RegNo;
    string ModelName;
    string Manufac;
    static int count;
    int Year;

public:
    Vehicle();
    Vehicle(string regNo, string model, string manufac, int year);
    inline string formatDisplay()
    {
        string s="RegNo: ";
        s+=RegNo;
        s+=", Model: ";
        s+=ModelName;
        s+=", Manufacturer: ";
        s+=Manufac;
        s+=", Year: ";
        s+=to_string(Year);
        return s;
    }
    virtual void DisplayInfo() = 0;
    ~Vehicle();
};

#endif