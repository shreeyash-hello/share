#include "Current.h"

int Current::minBalance = 1000;
float Current::interestRate = 0.01;

Current::Current()
{
    balance = 1000;
    transactionsPerDay = 0;
}

void Current::AcceptCurrentData()
{
    AcceptDetails();
}

bool Current::Deposit(double amt)
{
    if (PinCheck())
    {
        balance += amt;
        transactionsPerDay++;
        cout << "Deposit successful\n";
        return true;
    }

    cout << "Wrong PIN\n";
    return false;
}

bool Current::Withdraw(double amt)
{
    if (!PinCheck())
    {
        cout << "Wrong PIN\n";
        return false;
    }

    if ((balance - amt) < minBalance)
    {
        cout << "Minimum balance must remain " << minBalance << endl;
        return false;
    }

    balance -= amt;
    transactionsPerDay++;
    cout << "Withdraw successful\n";
    return true;
}

void Current::Transact()
{
    int choice;

    do
    {
        cout << "\n1 Deposit\n2 Withdraw\n3 Show Balance\n4 Exit\n";
        cin >> choice;

        double amt;

        switch (choice)
        {
        case 1:
            cout << "Enter amount: ";
            cin >> amt;
            Deposit(amt);
            break;

        case 2:
            cout << "Enter amount: ";
            cin >> amt;
            Withdraw(amt);
            break;

        case 3:
            ShowBalance();
            break;
        }

    } while (choice != 4);
}

void Current::DisplayAccount()
{
    if (PinCheck())
    {
        DisplayBasic();
        cout << "Account Type: Current\n";
        cout << "Transactions today: " << transactionsPerDay << endl;
    }
}