#ifndef SAVINGS_H
#define SAVINGS_H

#include "Bank.h"

class Savings : public BankAccount
{
private:
    int chequeBookNo;
    static int minBalance;
    static float interestRate;

public:
    Savings();

    void AcceptSavingsData();

    bool Deposit(double amt);
    bool Withdraw(double amt);

    void Transact();
    void DisplayAccount();

    ~Savings();
};

#endif