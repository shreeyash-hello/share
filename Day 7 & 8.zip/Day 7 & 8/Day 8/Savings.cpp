#include "Savings.h"

int Savings::minBalance = 2000;
float Savings::interestRate = 0.04;

Savings::Savings()
{
    balance = 2000;
    chequeBookNo = 589000;
}

void Savings::AcceptSavingsData()
{
    AcceptDetails();
    chequeBookNo++;
    cout << "Cheque Book Number: " << chequeBookNo << endl;
}

bool Savings::Deposit(double amt)
{
    if (PinCheck())
    {
        balance += amt;
        cout << "Deposit successful\n";
        return true;
    }

    cout << "Wrong PIN\n";
    return false;
}

bool Savings::Withdraw(double amt)
{
    if (!PinCheck())
    {
        cout << "Wrong PIN\n";
        return false;
    }

    if ((balance - amt) < minBalance)
    {
        cout << "Minimum balance must remain " << minBalance << endl;
        return false;
    }

    balance -= amt;
    cout << "Withdraw successful\n";
    return true;
}

void Savings::Transact()
{
    int choice;

    do
    {
        cout << "\n1 Deposit\n2 Withdraw\n3 Show Balance\n4 Exit\n";
        cin >> choice;

        double amt;

        switch (choice)
        {
        case 1:
            cout << "Enter amount: ";
            cin >> amt;
            Deposit(amt);
            break;

        case 2:
            cout << "Enter amount: ";
            cin >> amt;
            Withdraw(amt);
            break;

        case 3:
            ShowBalance();
            break;
        }

    } while (choice != 4);
}

void Savings::DisplayAccount()
{
    if (PinCheck())
    {
        DisplayBasic();
        cout << "Account Type: Savings\n";
        cout << "Interest Rate: " << interestRate * 100 << "%\n";
    }
}

Savings::~Savings() {}