#ifndef BANK_H
#define BANK_H

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class BankAccount
{
private:
    int AccNo;
    vector<string> holders;
    string mobile, email;
    int Pin;

protected:
    int balance;
    static int count;

public:
    BankAccount();

    void AcceptDetails();
    bool PinCheck();
    void DisplayBasic();

    virtual void DisplayAccount() = 0;
    virtual bool Withdraw(double amt) = 0;
    virtual bool Deposit(double amt) = 0;

    void ChangePin();
    int getAccount();
    void ShowBalance();

    virtual ~BankAccount();
};

#endif