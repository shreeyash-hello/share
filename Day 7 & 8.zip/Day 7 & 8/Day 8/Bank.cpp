#include "Bank.h"

int BankAccount::count = 253000;

BankAccount::BankAccount()
{
    AccNo = ++count;
    balance = 0;
}

void BankAccount::AcceptDetails()
{
    cout << "Account Number: " << AccNo << endl;

    char joint;
    int n;

    cout << "Is this a joint account? (y/n): ";
    cin >> joint;
    cin.ignore();

    if (joint == 'y' || joint == 'Y')
    {
        cout << "Enter number of account holders: ";
        cin >> n;
        cin.ignore();
    }
    else
        n = 1;

    string name;

    for (int i = 0; i < n; i++)
    {
        cout << "Enter holder name " << i + 1 << ": ";
        getline(cin, name);
        holders.push_back(name);
    }

    do
    {
        cout << "Enter mobile number: ";
        cin >> mobile;

        if (mobile.length() != 10)
            cout << "Invalid mobile number\n";

    } while (mobile.length() != 10);

    cout << "Enter Email: ";
    cin >> email;

    cout << "Set PIN: ";
    cin >> Pin;
}

bool BankAccount::PinCheck()
{
    int pincheck;

    cout << "Enter PIN: ";
    cin >> pincheck;

    return pincheck == Pin;
}

void BankAccount::DisplayBasic()
{
    cout << "Account No: " << AccNo << endl;

    cout << "Account Holders:\n";
    for (int i = 0; i < holders.size(); i++)
        cout << i + 1 << ". " << holders[i] << endl;

    cout << "Mobile: " << mobile << endl;
    cout << "Email: " << email << endl;
}

int BankAccount::getAccount()
{
    return AccNo;
}

void BankAccount::ChangePin()
{
    if (PinCheck())
    {
        int p1, p2;

        cout << "Enter new PIN: ";
        cin >> p1;

        do
        {
            cout << "Re-enter new PIN: ";
            cin >> p2;

            if (p1 != p2)
                cout << "PIN mismatch\n";

        } while (p1 != p2);

        Pin = p1;
        cout << "PIN updated successfully\n";
    }
    else
        cout << "Wrong PIN\n";
}

void BankAccount::ShowBalance()
{
    if (PinCheck())
        cout << "Current balance: " << balance << endl;
    else
        cout << "Wrong PIN\n";
}

BankAccount::~BankAccount() {}