#ifndef CURRENT_H
#define CURRENT_H

#include "Bank.h"

class Current : public BankAccount
{
private:
    int transactionsPerDay;
    static int minBalance;
    static float interestRate;

public:
    Current();

    void AcceptCurrentData();
    void Transact();

    bool Deposit(double amt);
    bool Withdraw(double amt);

    void DisplayAccount();
};

#endif