#include "Car.h"
#include <iostream>
using namespace std;

Car::Car(int h) : Vehicle(h){}

void Car::CalculateCharge()
{
    int total = 100;
    int extra = 0;

    if(hours > 3)
    {
        extra = extraCharge(hours - 3);
        total += extra;
    }

    cout << "Vehicle type = Car" << endl;
    cout << "Extra charge = Rs. " << extra << endl;
    cout << "Total Parking Charge = Rs. " << total << endl;
}