#include<iostream>
#include "Vehicle.h"
using namespace std;

int Vehicle::count = 0;

Vehicle::Vehicle(){
    hours = 0;
}

Vehicle::Vehicle(int hrs){
    hours = hrs;
    count++;
}

int Vehicle::getCount(){
    return count;
}