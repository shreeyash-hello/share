#include "Truck.h"
#include <iostream>
using namespace std;

Truck::Truck(int h, string code) : Vehicle(h){
    discountCode = code;
}

string Truck::getCode(){
    return discountCode;
}

void Truck::CalculateCharge(){
    int total = 200;
    int extra = 0;

    if(hours > 2)
    {
        extra = extraCharge(hours - 2);
        total += extra;
    }

    if(discountCode == "TRUCK50")
        total -= 50;

    cout << "Vehicle type = Truck" << endl;
    cout << "Extra charge = Rs. " << extra << endl;
    cout << "Total Charge after discount = Rs. " << total << endl;
}