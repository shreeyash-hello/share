#include <iostream>
#include "Car.h"
#include "Truck.h"
#include <string>

using namespace std;

template <typename T>
bool validateCode(T code)
{
    return code == "TRUCK50";
}

int main()
{
    char type;
    int hours, in;
    string code;

    Vehicle* v[100];

    do{

        try
        {
            cout << "Enter type of Vehicle (C for Car, T for Truck): ";
            cin >> type;

            if(type!='C' && type!='T')
                throw "Invalid vehicle type";

            cout << "Enter parking hours: ";
            cin >> hours;

            if(hours <= 0)
                throw "Parking hours must be positive";

            if(type == 'C')
            {
                v[Vehicle::getCount()] = new Car(hours);
            }
            else
            {
                cin.ignore();
                cout << "Enter discount code if available (or press Enter to skip): ";
                getline(cin, code);

                if(!validateCode(code))
                    code = "";

                v[Vehicle::getCount()] = new Truck(hours, code);
            }

            v[Vehicle::getCount()]->CalculateCharge();

            cout << "Receipts generated so far: "
                << Vehicle::getCount() << endl;

        }
        catch(const char* e)
        {
            cout << "Error: " << e << endl;
        }
        cout << "Enter 1 to enter another entry 0 to exit: ";
        cin >> in;
    }while (in != 0);
    return 0;
}