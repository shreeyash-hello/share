#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <string>
using namespace std;

class Vehicle
{
protected:
    int hours;
    static int count;
    
public:
    Vehicle();
    Vehicle(int hrs);
    virtual void CalculateCharge() = 0;
    static int getCount();
};


#endif