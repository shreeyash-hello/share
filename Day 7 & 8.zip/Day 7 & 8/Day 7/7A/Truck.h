#include "Vehicle.h"
#include <string>

class Truck : public Vehicle
{
private:
    string discountCode;

public:

    Truck(int h, string code);
    void CalculateCharge();
    inline int extraCharge(int h)
    {
        return h * 50;
    }
    string getCode();
};

