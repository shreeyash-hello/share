#include "Vehicle.h"

class Car : public Vehicle
{
public:
    Car();
    Car(int h);
    void CalculateCharge();
    inline int extraCharge(int h)
    {
        return h * 30;
    }
};