#include <iostream>
using namespace std;
#include "Vehicle.h"

int Vehicle::count = 0;

Vehicle::Vehicle(){
    RegNo = " ";
    ModelName = " ";
    Manufac = " ";
    Year = 2000;

}

Vehicle::Vehicle(string regNo, string model, string manufac, int year){
    RegNo = regNo;
    ModelName = model;
    Manufac = manufac;
    Year = year;
    Vehicle::count++;
}

Vehicle::~Vehicle(){}