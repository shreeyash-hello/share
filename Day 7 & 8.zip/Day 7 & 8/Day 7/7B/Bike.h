#include <iostream>
#include <string>
#include "Vehicle.h"

using namespace std;

class Bike: public Vehicle
{
private:
    string engine;
public:
    Bike();
    Bike(string regNo, string model, string manufac, 
    int year, string eng);
    void DisplayInfo();
    void writeToFile(ofstream &fout);
    ~Bike();
};
