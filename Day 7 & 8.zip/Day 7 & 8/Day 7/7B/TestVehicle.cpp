#include <iostream>
#include <string>
#include <fstream>
#include <cstring>
#include "Vehicle.h"
#include "Bike.h"
#include "Car.h"
using namespace std;

template <typename T>
bool validateYear(T year)
{
    time_t t = time(0);
    tm* now = localtime(&t);
    int currentYear = now->tm_year + 1900;

    return (year >= 2000 && year <= currentYear);
}


void AcceptData(Vehicle *v[], string tp){
    string reg, model, manufac, vehicle;
    int year;
    bool check = false;

    do
    {   try{
            cout << "Enter Registration number: ";
            cin.ignore();
            getline(cin, reg);
            if(reg == ""){
                check = true;
                throw "Registration number cannot be empty";
            }
            else{
                check = false;
            }
        }catch(const char* e){
            cout << e << endl;
        }
    } while (check);

    cout << "Enter Model name: ";
    cin >> model;

    cout << "Enter Manufacturer: ";
    cin >> manufac;

    check = false;

    do
    {
        try{
            cout << "Enter year: ";
            cin >> year;
            if(!validateYear(year)){
                check = true;
                throw "Invalid year";
            }else{
                check = false;
            }
        }catch(const char* e){
            cout << e << endl;
        }
    } while (check);

    if (tp == "C")
    {
        cout << "Enter Fuel Type: ";
        cin >> vehicle;

        v[Vehicle::getCount()] = new Car(reg, model, manufac, year, vehicle);
    }else
    {
        cout << "Enter Engine Capacity: ";
        cin >> vehicle;

        v[Vehicle::getCount()] = new Bike(reg, model, manufac, year, vehicle);

    }
}


int main(){
    int n;
    string type;

    cout << "Enter number of vehicles: ";
    cin >> n;

    Vehicle* v[n];

    for (int i = 0; i<n; i++){
        cout << "Enter type of vehicle (C for Car, B for Bike): ";
        cin >> type;
        if(type == "C"){
            AcceptData(v, "C");
        }else{
            AcceptData(v, "B");
        }
    }

    for(int i = 0; i<Vehicle::getCount(); i++){
        v[i]->DisplayInfo();
    }

    cout << "------------------------------------------------" << endl;
    cout << "Total Vehicles stored: " << Vehicle::getCount() << endl;


    return 0;

}
