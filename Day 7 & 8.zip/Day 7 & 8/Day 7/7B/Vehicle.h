#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <string>
using namespace std;

class Vehicle
{
protected:
    string RegNo;
    string ModelName;
    string Manufac;
    static int count;
    int Year;

public:
    Vehicle();
    Vehicle(string regNo, string model, string manufac, int year);
    virtual void DisplayInfo() = 0;
    inline string formatDisplay()
    {
        string s = "RegNo: " + RegNo +
                   ", Model: " + ModelName +
                   ", Manufacturer: " + Manufac +
                   ", Year: " + to_string(Year);
        return s;
    }

    static int getCount(){
        return count;
    }
    ~Vehicle();
};

#endif