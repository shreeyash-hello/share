package com.day12.lambda;

import java.util.*;
import java.time.LocalDate;
import java.util.function.*;

public class TransactionsMain {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<Transaction> list = new ArrayList<>();
        list.add(new Transaction(12, 23455, true, false));
        list.add(new Transaction(34, 1200, true, false));
        list.add(new Transaction(24, 2300, false, true));
        list.add(new Transaction(91, 5002, true, false));

//        for(int i = 0; i < 5; i++) {
//            System.out.println("Enter txId:");
//            int id = scanner.nextInt();
//
//            System.out.println("Enter date (yyyy-mm-dd):");
//            LocalDate date = LocalDate.parse(scanner.next());
//
//            System.out.println("Enter amount:");
//            float amt = scanner.nextFloat();
//
//            System.out.println("Enter status (true/false):");
//            boolean status = scanner.nextBoolean();
//
//            System.out.println("Enter arrears (true/false):");
//            boolean arrears = scanner.nextBoolean();
//
//            list.add(new Transaction(id, date, amt, status, arrears));
//        }

        System.out.println("\nTransactions > 5000:");
        Function<Transaction, Boolean> highamt = a -> {
        	return a.txAmount > 5000;
        };
        for(Transaction amt: list) {
        	if(highamt.apply(amt)) {
        		System.out.println(amt);
        	}
        }

        System.out.println("\nTransactions with status false:");
        Function<Transaction, Boolean> status = a -> {
        	return !a.txStatus;
        };
        for(Transaction stat: list) {
        	if(status.apply(stat)) {
        		System.out.println(stat);
        	}
        }

        Function<Transaction, Double> amountDue = (t) -> {
            if(t.txArrears)
                return t.txAmount + 500 + (0.18 * t.txAmount);
            else
                return (double)t.txAmount;
        };

        System.out.println("\nAmount Due:");
        for(Transaction transact : list) {
            System.out.println("TxId: " + transact.txId + " Due: " + amountDue.apply(transact));
        }

        scanner.close();
    }
}
