import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class lambda {
	public static void main(String [] args ) {
		int arr[]= {56,23,686,1,305};
		String sarr[]= {"J","T","M","W","A"};
		ArrayList<String> arrString = new ArrayList<>();
		arrString.add("V");
		arrString.add("R");
		arrString.add("A");
		arrString.add("G");
		arrString.add("T");
		
		Function<int [], Integer> arrInt = sortInt -> {
			int sorted = arr[0];
			for(int i : sortInt) {
				if(i > sorted) {
					sorted = i;
				}
			}
			return sorted;
		};
		System.out.println("Largest element is: " + arrInt.apply(arr));
		
		Function<int [], Integer> arrInt1 = sortInt -> {
			int sorted = arr[0];
			for(int i : sortInt) {
				if(i < sorted) {
					sorted = i;
				}
			}
			return sorted;
		};
		System.out.println("Smallest element is: " + arrInt1.apply(arr));
		
		Supplier<Integer> generate = () -> {
			return  ((int)(Math.random()*900)+100);
		};
		System.out.println("Random generated number is: " + generate.get());
		
		
        Function<int[], int[]> rev = (a) -> {
            int[] r = new int[a.length];
            for(int i = 0; i < a.length; i++)
                r[i] = a[a.length - 1 - i];
            return r;
        };
        System.out.println("Reversed array is: " + rev.apply(arr));
		
        Runnable date = () -> System.out.println("Date: " + LocalDate.now());
        date.run();
        
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter the number to check");
			int num = scanner.nextInt();
		
	        Predicate<Integer> primeCheck = check -> {
	        	if(check <= 1) return false;
	            for(int i = 2; i < check; i++)
	                if(check % i == 0) 
	                	return false;
	            return true;
	        };
	        if(primeCheck.test(num) == true) {
	        	System.out.println("\nThe number " + num + " is a prime number");
	        }else if(primeCheck.test(num) == false){
	        	System.out.println("\nThe number " + num + " is not a prime number");
	        }
	        
	        System.out.println("Enter the first string");
	        String str1 = scanner.next();
	        
	        System.out.println("Enter the second string");
	        String str2 = scanner.next();
	        
	        BiFunction<String, String, String> concat = (a, b) -> {
	        	return a + b;
	        }; 
	        System.out.println("Concatenated string is: " + concat.apply(str1, str2));
	        
        }
        
        
	}
	
}
