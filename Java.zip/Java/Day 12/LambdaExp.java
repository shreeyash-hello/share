package com.day11.lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.function.Function;
import java.util.function.Supplier;

public class LambdaExp {

	public static void main(String[] args) {
		
		String [] arrAlphabets = {"Dog", "Kangaroo", "Rabbit", "Cat"};
		System.out.println("Original array of Strings");
		for(String arr: arrAlphabets) {
			System.out.println(arr);
		}
		
		int [] arrInt = {2,4,6,1,9,1};
		System.out.println("Original array of Strings");
		for(int arr: arrInt) {
			System.out.println(arr);
		}
		
		// 1
		Arrays.sort(arrAlphabets, (a, b) -> a.compareTo(b));
		System.out.println("Sorted array of Strings");
		for(String arr: arrAlphabets) {
			System.out.println(arr);
		}
		
		// 2
		Function<int[], Integer> max = a -> {
			int check = a[0];
			for(int i: a) {
				if(i > check) {
					check = i;
				}
			}
			return check;
		};
		System.out.println("Largest element is: " + max.apply(arrInt));
		
		// 3
		Function<int[], Integer> min = a -> {
			int check = a[0];
			for(int i: a) {
				if(i < check) {
					check = i;
				}
			}
			return check;
		};
		System.out.println("Smallest element is: " + min.apply(arrInt));
		
		Supplier<Integer> genNo = () -> {
			int randomNo = (int) (Math.random()*10);
			return randomNo;
		};
		System.out.println("Random number from ");

	}

}
