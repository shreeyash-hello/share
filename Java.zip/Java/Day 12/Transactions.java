package com.day12.lambda;

import java.time.LocalDate;

class Transaction {
    int txId;
//    LocalDate txDate;
    float txAmount;
    boolean txStatus;
    boolean txArrears;

    public Transaction(int txId, float txAmount, boolean txStatus, boolean txArrears) {
        this.txId = txId;
//        this.txDate = txDate;
        this.txAmount = txAmount;
        this.txStatus = txStatus;
        this.txArrears = txArrears;
    }

    public String toString() {
        return txId + " " + txAmount + " " + txStatus + " " + txArrears;
    }
}
