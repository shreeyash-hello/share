public class GetDate {
	
	private int d;
	private int m;
	private int y;
	
	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		this.m = m;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public void acceptDate() {
		int day, month, year;
	    while(true) {
	        System.out.println("Enter day: ");
	        day = GetInput.getInt();

	        System.out.println("Enter month: ");
	        month = GetInput.getInt();

	        System.out.println("Enter year: ");
	        year = GetInput.getInt();

	        if (validateDate(day, month, year)) {
	            setD(day);
	            setM(month);
	            setY(year);
	            break;
	        }else {
	            System.out.println("Invalid date, try again.\n");
	        }   
	    }
	}
	
	public void DisplayDate() {
		System.out.println("The date is: " + d + " / "+ m + " / " + y);
	}
	
	public boolean validateDate(int d, int m, int y) {

	    if (m < 1 || m > 12) {
	    	return false;
	    }
	    
	    if (d <= 0) {
	    	return false;
	    }
	    
	    if(y > 3000 || y < 1900) {
	    	return false;
	    }
	    
	    if (m == 2) {
	        if (validateLeapYear(y)) {
	        	if (d > 29) {
	        	    return false;   
	        	} else {
	        	    return true;   
	        	}
	        } else {
	        	if (d > 28) {
	        	    return false;   
	        	} else {
	        	    return true;    
	        	}
	        }
	    }

	    if (m == 4 || m == 6 || m == 9 || m == 11) {
	    	if (d > 30) {
	    	    return false;   
	    	} else {
	    	    return true;    
	    	}
	    }

	    if (d > 31) {
	        return false;   
	    } else {
	        return true;    
	    }
	}
	
	public boolean validateLeapYear(int year) {
		if((this.y % 100 != 0 && this.y % 4 == 0) || 
				(this.y % 100 == 0 && this.y % 400 == 0)) {
			return true;
		}else {
			return false;
		}
	}
	
	public void addDays(int days) {
	    int currday = this.d + days;
	    while (true) {
	        if (this.m == 2) {
	            if (validateLeapYear(this.y)) {
	                if (currday <= 29) {
	                	break;
	                }
	                currday = currday - 29;
	            } else {
	                if (currday <= 28) {
	                	break;
	                }
	                currday = currday - 28;
	            }
	            this.m++;
	        }

	        else if (this.m == 4 || this.m == 6 || this.m == 9 || this.m == 11) {
	            if (currday <= 30) {
	            	break;
	            }
	            currday = currday - 30;
	            this.m++;
	        }else {

	            if (currday <= 31) {
	            	break;
	            }
	            currday = currday - 31;
	            this.m++;
	        }
	        if (this.m > 12) {
	            this.m = 1;
	            this.y++;
	        }
	    }
	    this.d = currday;
	}

	public void addMonths(int months) {
	    this.m += months;
	    this.y += (this.m - 1) / 12;
	    this.m = ((this.m - 1) % 12) + 1;

	    if (this.m == 2) {
	        if (validateLeapYear(this.y)) {
	            if (this.d > 29) {
	                this.d = 29;
	            }
	        } else {
	            if (this.d > 28) {
	                this.d = 28;
	            }
	        }
	    }

	    else if (this.m == 4 || this.m == 6 || this.m == 9 || this.m == 11) {
	        if (this.d > 30) {
	            this.d = 30;
	        }
	    }
	}
	
	public void addYears(int years) {
	    this.y += years;
	    if (this.m == 2 && this.d == 29) {
	        if (!validateLeapYear(this.y)) {
	            this.d = 28;
	        }
	    }
	}
	
	public boolean isEqual(GetDate date2) {

	    if (this.d == date2.d &&
	        this.m == date2.m &&
	        this.y == date2.y) {
	        return true;
	    }

	    return false;
	}
}