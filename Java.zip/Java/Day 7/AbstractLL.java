
public interface AbstractLL {
	
	public Object getData();
	public Node getStart();
	public Node getNext();
	public Node getLast();

}