public class LinkedList implements AbstractLL{

	Node start;
	Node end;
	Node current;
	int maxCount;
	
	
	public void add(Object data) {
		Node tempNode = new Node(data);
		
		if(start == null) {
			start = end = current = tempNode;
		}else {
			end.next = tempNode;
			tempNode.previous = end;
			end = tempNode;
		}
		maxCount++;
	}
	
	public void delete(int index) {
		if(start == null || index > maxCount) {
			return;
		}
		if(start == end) {
			start = end = current = null;
		}else if(index == 0) {
			start = start.next;
			start.previous = null;
		}else if(index == maxCount - 1) {
			end = end.previous;
			end.next = null;
		}else {
			Node tempNode = start;
			
			for(int i = 0; i < index; i++, tempNode = tempNode.next) {
				tempNode.previous.next = tempNode.next;
				tempNode.next.previous = tempNode.previous;
				
				tempNode = null;
			}
			maxCount--;
		}
	}

	@Override
	public Node getStart() {
		if(start == null) {
			return null;
		}
		current = start;
		return current;
	}

	@Override
	public Node getNext() {
		if(start == null || current == end) {
			return null;
		}
		current = current.next;
		return current;
		
	}

	@Override
	public Object getData() {
		return current.data;
	}

	@Override
	public Node getLast() {
		return end;
	}
	
	

	
}