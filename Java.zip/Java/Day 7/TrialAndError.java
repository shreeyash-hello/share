//package com.day7.antactica;
//
//import com.day2.GetInput;
//
//public class TrialAndError {
//
//	public static Employee acceptEmpData() {
//
//			System.out.print("Enter name: ");
//		    String name = GetInput.inputString();
//
//		    System.out.print("Enter address: ");
//		    String address = GetInput.inputString();
//	
//		    try {
//		    	System.out.print("Enter age: ");
//		    	int age = GetInput.getInt();
//		    	if(age < 0 || age > 100) {
//		    		throw new Exception("Invalid age entered!!");
//		    	}
//		    }catch(Exception e)
//		    {
//		    	System.out.println("Invalid");
//		    }
//	
//		    System.out.print("Enter gender (true/false): ");
//		    boolean gender = Boolean.parseBoolean(GetInput.inputString());
//	
//		    System.out.print("Enter basic salary: ");
//		    float salary = GetInput.getInt();
//	
//		    System.out.println("1. Manager"
//		    		+ "\n2. Engineer"
//		    		+ "\n3. Salesman");
//		    int choice = GetInput.getInt();
//
//	    switch(choice) {
//	        case 1:
//	            System.out.print("Enter HRA: ");
//	            int hra = GetInput.getInt();
//	            Manager objManager = new Manager(name, address, age, gender, salary, hra);
//	            return objManager;
//
//	        case 2:
//	            System.out.print("Enter Over Time: ");
//	            int ot = GetInput.getInt();
//	            Engineer objEngineer = new Engineer(name, address, age, gender, salary, ot);
//	            return objEngineer;
//
//	        case 3:
//	            System.out.print("Enter Commission: ");
//	            float commission = GetInput.getFloat();
//	            Salesman objSalesman = new Salesman(name, address, age, gender, salary, commission);
//	            return objSalesman;
//	    }
//
//	    return null;
//	}
//}
