import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class OtpMain {
	static Producer otpProducer = new Producer();
	static Set<String> otpSet = Collections.synchronizedSet(new HashSet<>());
	
	public static void main(String[] args) {
		
		Producer produceOtp = new Producer();
		Thread consThread = new Thread(produceOtp);
		consThread.start();
		
        
        try {
			consThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 
        System.out.println("Main: Waiting for Producer to finish...");
		
		Consumer consume = new Consumer();
		Thread consumeThread = new Thread(consume);
		consumeThread.start();
	}

}
