
import java.util.function.Supplier;

public class Producer implements Runnable {

	private String [] vowels = {"A", "E", "I", "O", "U"};
		
		public String generateOtp(){
			Supplier<Integer> genAlp = () -> {
				int randomNo=(int)(Math.random()*4);
				return randomNo;
			};
			
			Supplier<Integer> genNo = () -> {
				int randomNo=(int)((Math.random()*9000) + 1000);
				return randomNo;
			};
			
			String otp = vowels[genAlp.get()] + genNo.get();				
			return otp;
		}

		@Override
		public void run() {
			for (int i = 0; i < 100; i++) {
	            String otp = generateOtp();
	            OtpMain.otpSet.add(otp);
	            System.out.println("Produced: " + otp);	
	        }
	    }
}
