import java.util.Iterator;

public class Consumer implements Runnable{
	
	int consumableItems = 79;
	int consumedItems = 0;

	@Override
	public void run() {
		synchronized (OtpMain.otpSet) {
            Iterator<String> iter = OtpMain.otpSet.iterator();

            while (iter.hasNext() && OtpMain.otpSet.size() > 20) {
                String val = iter.next();
                System.out.println("Consumed: " + val);
                iter.remove();
            }
        }
        System.out.println("Consumer: Finished. Remaining items: " + OtpMain.otpSet.size());
		
	
	}


}

