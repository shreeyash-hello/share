public class EmployeeMain {

	public static void main(String[] args) {
		
		int choice = 0;
		
		final int MENU_ADD = 1;
		final int MENU_DISPLAY = 2;
		final int MENU_SORT = 3;
		final int MENU_EXIT = 4;
		
//		Employee [] arrEmployee = new Employee[100];
		LinkedList objEmployee = new LinkedList();
		
		do {
			
			System.out.println("\nChoose among the following");
			System.out.println("1. Add");
			System.out.println("2. Display");
			System.out.println("3. Sort");
			System.out.println("4. Exit");
			
			choice = GetInput.getInt();
			
			switch(choice) {

				case MENU_ADD:
				{
					Employee emp = acceptEmpData();
				    if(emp != null)
				        objEmployee.add(emp);
				}
				break;
				
				case MENU_DISPLAY:
				{
					displayEmp(objEmployee);
				}
				break;
				
				case MENU_SORT:
				{
					int sort_choice = 0;
					do {
					
						System.out.print("\n1. Sort Manager by Salary");
						System.out.print("\n2. Sort Engineer by Salary");
						System.out.print("\n3. Sort Salesman by Salary");
						System.out.print("\n4. Sort all Employees by name in ascending order");
						System.out.print("\n5. Sort all Employees by name in descending order");
						System.out.print("\n6. Exit : ");
						System.out.print("\nEnter your choice: ");
						
						final int SORT_MANAGER = 1;
						final int SORT_ENGINEER = 2;
						final int SORT_SALESMAN = 3;
						final int SORT_NAME_ASC = 4;
						final int SORT_NAME_DESC = 5;
						final int EXIT_SORT = 6;
						
						
						sort_choice = GetInput.getInt();
						
						switch(sort_choice) {
							case SORT_MANAGER:
							{
								int post = 1;
								System.out.println("Sorted Manager salaries are");
								sortEmpSal(post, objEmployee);							
							}
							break;
							
							case SORT_ENGINEER:
							{
								int post = 2;
								System.out.println("Sorted Engineer salaries are");
								sortEmpSal(post, objEmployee);
							}
							break;
							
							case SORT_SALESMAN:
							{
								int post = 3;
								System.out.println("Sorted Salesman salaries are");
								sortEmpSal(post, objEmployee);
							}
							break;
							
							case SORT_NAME_ASC:
							{
								int sort = 1;
								System.out.println("Sorted Employee names in ascending order");
								sortByName(sort, objEmployee);
							}
							break;
							
							case SORT_NAME_DESC:
							{
								int sort = 2;
								System.out.println("Sorted Employee names in descending order");
								sortByName(sort, objEmployee);
							}
							break;
							
							case EXIT_SORT:
							{
								System.out.println("Program exit!!");								
							}
							break;
							
							default:
							{
								System.out.println("Invalid choice!!");						
							}
							break;
						}
					}while(sort_choice != 6);					
				}
				
				case MENU_EXIT:
				{
					System.out.print("Program exit!!");					
				}
				break;
				
				default:
				{
					System.out.println("Invalid choice!!");					
				}
				break;
			}
			
		}while(choice != 4);

	}
	
	public static void sortEmpSal(int pos, LinkedList list) {
	    Node temp = list.start;
	    int count = 0;
	    
	    while(temp != null) {
	        Employee emp = (Employee) temp.data;
	        if( (pos == 1 && emp instanceof Manager) ||
	            (pos == 2 && emp instanceof Engineer) ||
	            (pos == 3 && emp instanceof Salesman) ) 
	        {
	            count++;
	        }
	        temp = temp.next;
	    }
	
	    float[] salaries = new float[count];
	
	    temp = list.start;
	    
	    int index = 0;
	
	    while(temp != null) {
	        Employee emp = (Employee) temp.data;
	        if( (pos == 1 && emp instanceof Manager) ||
	            (pos == 2 && emp instanceof Engineer) ||
	            (pos == 3 && emp instanceof Salesman) )
	        {
	            salaries[index] = emp.calculateSal();
	            index++;
	        }
	        temp = temp.next;
	    }
	
	    for(int i = 0; i < count - 1; i++) {
	        for(int j = 0; j < count - 1 - i; j++) {
	            if(salaries[j] > salaries[j + 1]) {
	                float tempVal = salaries[j];
	                salaries[j] = salaries[j + 1];
	                salaries[j + 1] = tempVal;
	            }
	        }
	    }
	
	    for(int i = 0; i < count; i++) {
	        System.out.println(salaries[i]);
	    }
	}
	
	public static void sortByName(int order, LinkedList list) {
	    Node temp = list.start;
	    int count = 0;
	    while(temp != null) {
	        count++;
	        temp = temp.next;
	    }

	    String[] names = new String[count];
	
	    temp = list.start;
	    int index = 0;
	
	    while(temp != null) {
	        Employee emp = (Employee) temp.data;
	        names[index] = emp.getName();
	        index++;
	        temp = temp.next;
	    }

	    for(int i = 0; i < count - 1; i++) {
	        for(int j = 0; j < count - 1 - i; j++) {
	            int result = names[j].compareTo(names[j + 1]);
	            if( (order == 1 && result > 0) || 
	                (order == 2 && result < 0) ) 
	            {
	                String tempName = names[j];
	                names[j] = names[j + 1];
	                names[j + 1] = tempName;
	            }
	        }
	    }

	    for(int i = 0; i < count; i++) {
	        System.out.println(names[i]);
	    }
	}
	
	public static void displayEmp(LinkedList list) {

	    Node temp = list.start;

	    if(temp == null) {
	        System.out.println("List is empty");
	        return;
	    }

	    while(temp != null) {

	        Employee emp = (Employee) temp.data;

	        System.out.println("\nName: " + emp.getName());
	        System.out.println("Address: " + emp.getAddress());
	        System.out.println("Age: " + emp.getAge());
	        System.out.println("Gender: " + emp.isGender());
	        System.out.println("Basic Salary: " + emp.getBasicSalary());

	        if(emp instanceof Manager) {
	            Manager m = (Manager) emp;
	            System.out.println("HRA: " + m.getHra());
	            System.out.println("Total Salary: " + m.calculateSal());

	        } else if(emp instanceof Engineer) {
	            Engineer e = (Engineer) emp;
	            System.out.println("OverTime: " + e.getOverTime());
	            System.out.println("Total Salary: " + e.calculateSal());

	        } else if(emp instanceof Salesman) {
	            Salesman s = (Salesman) emp;
	            System.out.println("Commission: " + s.getCommission());
	            System.out.println("Total Salary: " + s.calculateSal());
	        }

	        temp = temp.next;
	    }
	}
	
	public static Employee acceptEmpData() {
		System.out.print("Enter name: ");
	    String name = GetInput.inputString();

	    System.out.print("Enter address: ");
	    String address = GetInput.inputString();

	    System.out.print("Enter age: ");
	    int age = GetInput.getInt();

	    System.out.print("Enter gender (true/false): ");
	    boolean gender = Boolean.parseBoolean(GetInput.inputString());

	    System.out.print("Enter basic salary: ");
	    float salary = GetInput.getInt();

	    System.out.println("1. Manager"
	    		+ "\n2. Engineer"
	    		+ "\n3. Salesman");
	    int choice = GetInput.getInt();

	    switch(choice) {
	        case 1:
	            System.out.print("Enter HRA: ");
	            int hra = GetInput.getInt();
	            Manager objManager = new Manager(name, address, age, gender, salary, hra);
	            return objManager;

	        case 2:
	            System.out.print("Enter Over Time: ");
	            int ot = GetInput.getInt();
	            Engineer objEngineer = new Engineer(name, address, age, gender, salary, ot);
	            return objEngineer;

	        case 3:
	            System.out.print("Enter Commission: ");
	            float commission = GetInput.getFloat();
	            Salesman objSalesman = new Salesman(name, address, age, gender, salary, commission);
	            return objSalesman;
	    }

	    return null;
	}
	
}




