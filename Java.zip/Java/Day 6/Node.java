
public class Node {

	Object data;
	
	Node previous;
	Node next;
	
	public Node(Object temp) {
		data = temp;
	}
	
}
