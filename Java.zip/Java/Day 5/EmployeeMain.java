public class EmployeeMain {

	public static void main(String[] args) {
		
		int choice = 0;
//		int count = 0;
		
		final int MENU_ADD = 1;
		final int MENU_DISPLAY = 2;
		final int MENU_SORT = 3;
		final int MENU_EXIT = 4;
		
		Employee [] arrEmployee = new Employee[100];
		
		do {
			
			System.out.println("\nChoose among the following");
			System.out.println("1. Add");
			System.out.println("2. Display");
			System.out.println("3. Sort");
			System.out.println("4. Exit");
			
			choice = GetInput.getInt();
			
			switch(choice) {
				case MENU_ADD:
				{
					int subChoice = 0;
					final int SUBMENU_MANAGER = 1;
					final int SUBMENU_ENGINNER = 2;
					final int SUBMENU_SALESMAN = 3;
					final int SUBMENU_EXIT = 4;
					
					System.out.print("Enter name: ");
					String name = GetInput.inputString();
					
					System.out.print("\nEnter address: ");
					String address = GetInput.inputString();
					
					System.out.print("\nEnter age: ");
					int age = GetInput.getInt();
					
					System.out.print("\nEnter gender (true for M false for F) : ");
					String temp = GetInput.inputString();
					boolean gender = Boolean.parseBoolean(temp);
					
					System.out.print("\nEnter basic salary: ");
					int basicSalary = GetInput.getInt();
					
					System.out.println("\nChoose among the following");
					System.out.println("1. Manager");
					System.out.println("2. Engineer");
					System.out.println("3. Salesperson");
					System.out.println("4. Exit");
					
					subChoice = GetInput.getInt();	
					
					switch(subChoice) {
						case SUBMENU_MANAGER:
						{
							System.out.print("\nEnter HRA : ");
							float hra = GetInput.getInt();
							arrEmployee[Employee.incrementCount()] = new Manager(name, address, age, gender, basicSalary, hra);
						}
						break;
						
						case SUBMENU_ENGINNER:
						{
							System.out.print("\nEnter Over Time : ");
							float ot = GetInput.getInt();
							arrEmployee[Employee.incrementCount()] = new Engineer(name, address, age, gender, basicSalary, ot);
						}
						break;
						
						case SUBMENU_SALESMAN:
						{
							System.out.print("\nEnter Commission : ");
							float commission = GetInput.getInt();
							arrEmployee[Employee.incrementCount()] = new Salesman(name, address, age, gender, basicSalary, commission);
						}
						break;
						
						case SUBMENU_EXIT:{
							System.out.print("\nProgram exit");
						}
						break;
					}
					
				}
				break;
				
				case MENU_DISPLAY:
				{
					for(int i = 0; i < Employee.getCount(); i++) {
						System.out.print("\nName: " + arrEmployee[i].getName());
						System.out.print("\nAddress: " + arrEmployee[i].getAddress());
						System.out.print("\nAge: " + arrEmployee[i].getAge());
						System.out.print("\nGender: " + arrEmployee[i].isGender());
						System.out.print("\nBasic Salary: " + arrEmployee[i].getBasicSalary());
						
						if(arrEmployee[i] instanceof Manager) {
							Manager objManager = (Manager) arrEmployee[i];
							System.out.print("\nHRA: " + objManager.getHra());
							System.out.print("\nTotal Salary: " + objManager.calculateSal());
							
						}else if(arrEmployee[i] instanceof Engineer) {
							Engineer objEngineer = (Engineer) arrEmployee[i];
							System.out.print("\nOver Time: " + objEngineer.getOverTime());
							System.out.print("\nTotal Salary: " + objEngineer.calculateSal());
							
						}else if(arrEmployee[i] instanceof Salesman) {
							Salesman objSalesman = (Salesman) arrEmployee[i];
							System.out.print("\nOver Time: " + objSalesman.getCommission());
							System.out.print("\nTotal Salary: " + objSalesman.calculateSal());
						}
					}
				}
				break;
				
				case MENU_SORT:
				{
					System.out.print("\n1. Sort Manager by Salary");
					System.out.print("\n2. Sort Engineer by Salary");
					System.out.print("\n3. Sort Salesman by Salary");
					System.out.print("\n4. Sort all Employees by name in ascending order");
					System.out.print("\n5. Sort all Employees by name in descending order");
					System.out.print("\n6. Exit : ");
					System.out.print("\nEnter your choice: ");
					
					final int SORT_MANAGER = 1;
					final int SORT_ENGINEER = 2;
					final int SORT_SALESMAN = 3;
					final int SORT_NAME_ASC = 4;
					final int SORT_NAME_DESC = 5;
					final int EXIT_SORT = 6;
					
					int sort_choice = 0;
					sort_choice = GetInput.getInt();
					
					switch(sort_choice) {
						case SORT_MANAGER:
						{
							int post = 1;
							System.out.println("Sorted Manager salaries are");
							sortEmpSal(post, arrEmployee);							
						}
						break;
						
						case SORT_ENGINEER:
						{
							int post = 2;
							System.out.println("Sorted Engineer salaries are");
							sortEmpSal(post, arrEmployee);
						}
						break;
						
						case SORT_SALESMAN:
						{
							int post = 3;
							System.out.println("Sorted Salesman salaries are");
							sortEmpSal(post, arrEmployee);
						}
						break;
						
						case SORT_NAME_ASC:
						{
							int sort = 1;
							System.out.println("Sorted Employee names in ascending order");
							sortByName(sort, arrEmployee);
						}
						break;
						
						case SORT_NAME_DESC:
						{
							int sort = 2;
							System.out.println("Sorted Employee names in descending order");
							sortByName(sort, arrEmployee);
						}
						break;
						
						case EXIT_SORT:
						{
							System.out.println("Program exit!!");
							break;
						}
						default:
						{
							System.out.println("Invalid choice!!");
							break;
						}
					}					
				}
				
				case MENU_EXIT:
				{
					System.out.print("Program exit!!");
					break;
				}
				
				
				default:
				{
					System.out.println("Invalid choice!!");
					break;
				}
			}
			
		}while(choice != 6);

	}
	
	public static void sortEmpSal(int pos, Employee [] arrEmployee) {
		
		
		int countEmps = 0;
		
		
		for(int i = 0; i < Employee.getCount(); i++) {
			if(pos == 1 && (arrEmployee[i] instanceof Manager)) {
				countEmps++;
			}else if(pos == 2 && (arrEmployee[i] instanceof Engineer)) {
				countEmps++;
			}else if(pos == 3 && (arrEmployee[i] instanceof Salesman)) {
				countEmps++;
			}
		}
		
		
		float [] arrTotalSal = new float[countEmps];
		
		int count = 0;
		
		for(int i = 0; i < Employee.getCount(); i++) {
			if(pos == 1 && (arrEmployee[i] instanceof Manager)) {
				Manager objManager = (Manager) arrEmployee[i];
				float totalSal = objManager.calculateSal();
				arrTotalSal[count++] = totalSal;
			}
			if(pos == 2 && (arrEmployee[i] instanceof Engineer)) {
				Engineer objEngineer = (Engineer) arrEmployee[i];
				float totalSal = objEngineer.calculateSal();
				arrTotalSal[count++] = totalSal;
			}
			if(pos == 3 && (arrEmployee[i] instanceof Salesman)) {
				Salesman objSalesman = (Salesman) arrEmployee[i];
				float totalSal = objSalesman.calculateSal();
				arrTotalSal[count++] = totalSal;
			}
		}
		
		
		for(int i = 0; i < count - 1; i++) {
		    for(int j = 0; j < count - 1 - i; j++) {
		        if(arrTotalSal[j] > arrTotalSal[j + 1]) {
		            float temp = arrTotalSal[j];
		            arrTotalSal[j] = arrTotalSal[j + 1];
		            arrTotalSal[j + 1] = temp;
		        }
		    }
		}
		
		for(int i = 0; i < count; i++) {
		    System.out.println(arrTotalSal[i]);
		}
	}
	
	public static void sortByName(int sort, Employee[] arrEmployee) {

	    for(int i = 0; i < Employee.getCount() - 1; i++) {
	        for(int j = 0; j < Employee.getCount() - 1 - i; j++) {
	            int result = arrEmployee[j].getName()
	                         .compareTo(arrEmployee[j + 1].getName());

	            if( (sort == 1 && result > 0) || (sort == 2 && result < 0) ) {	              
	                Employee temp = arrEmployee[j];
	                arrEmployee[j] = arrEmployee[j + 1];
	                arrEmployee[j + 1] = temp;
	            }
	        }
	    }	    
	    for(int i = 0; i < Employee.getCount(); i++) {
	        System.out.println(arrEmployee[i].getName());
	    }
	}

}



