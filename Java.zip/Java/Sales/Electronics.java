package com.sales;

public class Electronics extends Products{

	private String name;
	private String product;
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = "Electronics";
	}

	public Electronics(String name) {
		setName(name);
	}
	
}
