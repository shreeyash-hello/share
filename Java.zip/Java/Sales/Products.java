package com.sales;

public abstract class Products {

}
