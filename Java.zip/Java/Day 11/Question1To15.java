import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.NavigableSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;

public class Question1To15 {
	public static void main(String [] args) {
		ArrayList<String> arrList = new ArrayList<>();
		arrList.add("Red");
		arrList.add("Blue");
		arrList.add("Green");
		arrList.add("Yellow");
		arrList.add("White");
		
		System.out.println("Original list is");
		display(arrList);
		
		arrList.add(1,"Crymson Red");
		System.out.println("Modified list is");
		display(arrList);
		
		System.out.println("2nd element is " + arrList.get(1));
		
		
		System.out.println("Changed 3rd element to violet");
		arrList.set(2, "Violet");
		display(arrList);
		
		System.out.println("Removed 2nd element");
		arrList.remove(1);
		display(arrList);
		
		
		System.out.println("Index of Green is" + arrList.indexOf("Green"));
		
		System.out.println("Sorted list is");
		Collections.sort(arrList);
		display(arrList);
		
		System.out.println("Copy of original list is");
		ArrayList<String> arrListcpy = new ArrayList<>(arrList);
		display(arrListcpy);
		
		System.out.println("Shuffled list is");
		Collections.shuffle(arrList);
		display(arrList);
		
		System.out.println("Reversed list is");
		Collections.reverse(arrList);
		display(arrListcpy);
		
		TreeSet<String> Colours = new TreeSet<>();
		
		Colours.add("Pink");
		Colours.add("Black");
		Colours.add("Orange");
		Colours.add("Grey");
		Colours.add("Metallic Black");
		System.out.println("Tree Set is");
		displayTreeSet(Colours);
		
		System.out.println("Reversed Tree Set is");
		TreeSet<String> coloursReverse= new TreeSet<>(Collections.reverseOrder());
		coloursReverse.addAll(Colours);
		displayTreeSet(coloursReverse);
		
		try {
			String firstElement = ((TreeSet<String>) Colours).first();
			System.out.println("First element in the Tree Set is " + firstElement);
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			String colour = "Black";
			String ceiling = coloursReverse.ceiling(colour);
			System.out.println("Greater than or equal to " + colour + " is " + ceiling);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}



	public static void displayTreeSet(TreeSet<String> arrList) {
		Iterator<String> iter = arrList.iterator();
		
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}

	
	
	public static void display(ArrayList<String> arrList) {
		Iterator<String> iter = arrList.iterator();
		
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
}
