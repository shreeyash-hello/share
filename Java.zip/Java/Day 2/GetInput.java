package com.pc22.batch2;

import java.io.IOException;

public class GetInput{
	public static int getInt() {
		try {
			String objString = inputString();
			int num = Integer.parseInt(objString);
			return num;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public static String inputString() throws IOException {
		try {
			byte [] input = new byte[100];
			System.out.println("Enter the number:");
			int len = System.in.read(input);
			byte [] finalInput = new byte[len - 2];
			System.arraycopy(input, 0, finalInput, 0, len-2);
			String objString = new String(finalInput);
			return objString;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "0";
	}
	
	public static float getFloat() {
		try {
			String objString = inputString();
			float num = Float.parseFloat(objString);
			return num;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1f;
	}
}
