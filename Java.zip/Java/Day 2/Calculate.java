package com.pc22.batch2;

public class Calculate {
	public static void calcu(int a, int b) {
		System.out.println("Addition is: " + (a+b));
	}
	public static void calcu(int a, int b, int c) {
		System.out.println("Addition is: " + (a+b+c));
	}
	public static void calcusub(int a, int b) {
		System.out.println("Subtraction is: " + (a-b));
	}
	public static void calcu(float a, float b) {
		System.out.println("Addition of decimal is: " + (a+b));
	}
	public static void calcudiv(int a, int b) {
		System.out.println("Division is: " + (a/b));
	}
	public static void calcumult(int a, int b) {
		System.out.println("Multiplication is: " + (a*b));
	}
	public static void calcu(int a, float b) {
		int result = (int)b + a;
		System.out.println("The addition is: " + result);
	}
	public static void calcu(float a, int b) {
		int result = (int)a + b;
		System.out.println("The addition is: " + result);
	}
}
