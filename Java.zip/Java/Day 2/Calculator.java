package com.pc22.batch2;
import java.io.IOException;
import java.util.*;

public class Calculator {
	
	public static void main(String [] args) {
		int choice = 0;
		do {
			System.out.println("Choose among the following options: ");
			System.out.println("1. Addition of two numbers "
					+ "\n2. Addition of two decimal numbers "
					+ "\n3. Subtraction of two numbers "
					+ "\n4. Division of two numbers "
					+ "\n5. Addition of three numbers "
					+ "\n6. Multiplication of two numbers "
					+ "\n7. Exit");
			
			choice = GetInput.getInt();
			switch(choice) {
				case 1:
				{
					int num1 = 0, num2 = 0;
					System.out.println("Enter the numbers now-------");
					num1 = GetInput.getInt();
					num2 = GetInput.getInt();
					Calculate.calcu(num1, num2);
					break;
				}
				case 2:
				{
					float num1 = 0f, num2 = 0f;
					System.out.println("Enter the numbers now-------");
					num1 = GetInput.getFloat();
					num2 = GetInput.getFloat();
					Calculate.calcu(num1, num2);
					break;
				}
				case 3:
				{
					int num1 = 0, num2 = 0;
					System.out.println("Enter the numbers now-------");
					num1 = GetInput.getInt();
					num2 = GetInput.getInt();
					Calculate.calcusub(num1, num2);
					break;
				}
				case 4:
				{
					int num1 = 0, num2 = 0;
					System.out.println("Enter the numbers now-------");
					num1 = GetInput.getInt();
					num2 = GetInput.getInt();
					Calculate.calcudiv(num1, num2);
					break;
				}
				case 5:
				{
					int num1 = 0, num2 = 0, num3 = 0;
					System.out.println("Enter the numbers now-------");
					num1 = GetInput.getInt();
					num2 = GetInput.getInt();
					num3 = GetInput.getInt();
					Calculate.calcu(num1, num2, num3);
					break;
				}
				case 6:
				{
					int num1 = 0, num2 = 0;
					System.out.println("Enter the numbers now-------");
					num1 = GetInput.getInt();
					num2 = GetInput.getInt();
					Calculate.calcumult(num1, num2);
					break;
				}
				case 7:
				{
					System.out.println("Program exit!! Yaaaaaaaaaaaaaaaaaaaaaaay !!!!!!!!!!!!!!!!");
					break;
				}
				default:
					System.out.println("Invalid choice Please try again !!");
			}
			
		}while(choice != 7);
	}

}



	
