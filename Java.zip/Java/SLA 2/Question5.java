package com.sla2.neptune;

class Employee {
    String name;
    int year;
    String address;

    Employee(String n, int y, String addr) {
        name = n;
        year = y;
        address = addr;
    }

    void display() {
        System.out.println(name + "\t" + year + "\t\t" + address);
    }

    public static void main(String[] args) {
        System.out.println("Name\tYear\tAddress");

        Employee e1 = new Employee("Robert", 1994, "64C-WallStreet");
        Employee e2 = new Employee("Sam", 2000, "68D-WallStreet");
        Employee e3 = new Employee("John", 1999, "26B-WallStreet");

        e1.display();
        e2.display();
        e3.display();
    }
}