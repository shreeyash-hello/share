package com.sla2.neptune;

class Rectangle1 {
    int length, breadth;

    Rectangle1(int l, int b) {
        length = l;
        breadth = b;
    }

    void area() {
        System.out.println("Area: " + (length * breadth));
    }

    void perimeter() {
        System.out.println("Perimeter: " + (2 * (length + breadth)));
    }
}

class Square extends Rectangle1 {
    Square(int side) {
        super(side, side);
    }

    public static void main(String[] args) {
        Rectangle1 r = new Rectangle1(10, 5);
        Square s = new Square(4);

        r.area();
        r.perimeter();

        s.area();
        s.perimeter();
    }
}
