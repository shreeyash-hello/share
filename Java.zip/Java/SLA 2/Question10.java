package com.sla2.neptune;

class Shape {
    void printShape() {
        System.out.println("This is shape");
    }
}

class Rectangle2 extends Shape {
    void printRectangle() {
        System.out.println("This is rectangular shape");
    }
}

class Circle extends Shape {
    void printCircle() {
        System.out.println("This is circular shape");
    }
}

class Square1 extends Rectangle2 {
    void printSquare() {
        System.out.println("Square is a rectangle");
    }

    public static void main(String[] args) {
        Square1 s = new Square1();

        s.printShape();
        s.printRectangle();
        s.printSquare();
    }
}
