package com.sla2.neptune;
import java.util.Scanner;

public class LLProgram1 {

    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
			LinkedList<Integer> list = new LinkedList<>();

			System.out.println("Enter 10 numbers:");
			for (int i = 0; i < 10; i++) {
			    list.add(sc.nextInt());
			}

			System.out.println("\nAll Numbers:");
			Node<Integer> temp = list.getStart();
			while (temp != null) {
			    System.out.print(list.getData() + " ");
			    temp = list.getNext();
			}

			// 🔹 b, c, d, e → highest, lowest, sum, avg
			temp = list.getStart();

			int max = list.getData();
			int min = list.getData();
			int sum = 0;
			int count = 0;

			while (temp != null) {
			    int val = list.getData();

			    if (val > max) max = val;
			    if (val < min) min = val;

			    sum += val;
			    count++;

			    temp = list.getNext();
			}

			System.out.println("\nHighest: " + max);
			System.out.println("Lowest: " + min);
			System.out.println("Sum: " + sum);
			System.out.println("Average: " + (sum / (double) count));

			System.out.print("\nEnter number to find index: ");
			int search = sc.nextInt();

			temp = list.getStart();
			int index = 0;
			boolean found = false;

			while (temp != null) {
			    if (list.getData() == search) {
			        System.out.println("Found at index: " + index);
			        found = true;
			        break;
			    }
			    index++;
			    temp = list.getNext();
			}

			if (!found) {
			    System.out.println("Number not found");
			}

			System.out.print("\nEnter number to count frequency: ");
			int freqNum = sc.nextInt();

			temp = list.getStart();
			int freq = 0;

			while (temp != null) {
			    if (list.getData() == freqNum) {
			        freq++;
			    }
			    temp = list.getNext();
			}

			System.out.println("Frequency: " + freq);
		}
    }
}
