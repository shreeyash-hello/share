package com.sla2.neptune;

class Parent {
    void show() {
        System.out.println("This is parent class");
    }
}

class Child extends Parent {
    void display() {
        System.out.println("This is child class");
    }

    public static void main(String[] args) {
        Parent p = new Parent();
        Child c = new Child();

        p.show();      
        c.display();   
        c.show();      
    }
}
