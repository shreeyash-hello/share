package com.sla2.neptune;
import java.util.Scanner;

public class LLProgram2 {

    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
			LinkedList<Integer> list = new LinkedList<>();

			int count = 0;

			System.out.println("Enter 10 UNIQUE numbers:");

			while (count < 10) {

			    int num = sc.nextInt();

			    Node<Integer> temp = list.getStart();
			    boolean exists = false;

			    while (temp != null) {
			        if (list.getData() == num) {
			            exists = true;
			            break;
			        }
			        temp = list.getNext();
			    }

			    if (!exists) {
			        list.add(num);
			        count++;
			    } else {
			        System.out.println("Duplicate! Enter another number:");
			    }
			}

			System.out.println("\nUnique Numbers:");
			Node<Integer> temp = list.getStart();
			while (temp != null) {
			    System.out.print(list.getData() + " ");
			    temp = list.getNext();
			}
		}
    }
}
