
class Rectangle {

	private int length;
	private int breadth;
	private double area;
	
	private void setArea(double area) {
		this.area = area;
	}
	
	private double getArea() {
		return area;
	}

	Rectangle(int s1, int s2){
		length = s1;
		breadth = s2;
	}
	
	public void calculateArea() {
		area = length*breadth;
		setArea(area);
	}
	
	public double displayArea() {
		return getArea();
	}

}

public class AreaRectangle{
	public static void main(String [] args) {
		Rectangle obj = new Rectangle(4,5);
		obj.calculateArea();
		Rectangle obj1 = new Rectangle(5,8);
		obj1.calculateArea();
		System.out.println("The area is: " + obj1.displayArea());
		System.out.println("The area is: " + obj.displayArea());
	}
}