package com.sla2.neptune;


class Member {
    private String name, phone, address;
    private int age;
    private double salary;


    void setData(String n, int a, String p, String addr, double sal) {
        name = n;
        age = a;
        phone = p;
        address = addr;
        salary = sal;
    }

    void printSalary() {
        System.out.println("Salary: " + salary);
    }

    void display() {
        System.out.println(name + " " + age + " " + phone + " " + address);
    }
}

class PrimeMember extends Member {
    int joiningYear;
    double joiningFees;
    boolean isActive;

    void setPrimeData(int year, double fees, boolean active) {
        joiningYear = year;
        joiningFees = fees;
        isActive = active;
    }

    void displayPrime() {
        display();
        System.out.println(joiningYear + " " + joiningFees + " " + isActive);
    }

    public static void main(String[] args) {
        PrimeMember pm = new PrimeMember();
        pm.setData("John", 25, "999999", "Pune", 50000);
        pm.setPrimeData(2022, 2000, true);

        pm.displayPrime();
        pm.printSalary();
    }
}
