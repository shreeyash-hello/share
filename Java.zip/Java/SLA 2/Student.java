
class StudentData {
	private String name;
	private int rollno;
	private String phoneno;
	private String address;
	
	StudentData(int roll, String nm){
		rollno = roll;
		name = nm;
	}
	
	StudentData(String phn, String addr, int roll, String nm){
		this(roll, nm);
		phoneno = phn;
		address = addr;
	}
	
	public void display() {
		System.out.println("Name : "+ name +
				"\nRoll Number : " + rollno );
	}
	
	public void display1() {
		System.out.println("Name : "+ name +
				"\nRoll Number : " + rollno +
				"\nPhone number : " + phoneno+
				"\nAddress : "+address);
	}
	
}



public class Student {

	public static void main(String[] args) {
		StudentData obj = new StudentData(2, "John");
		obj.display();
		
		StudentData obj1 = new StudentData("999999", "Pune", 3, "Sam");
		obj1.display1();
		
		StudentData obj2 = new StudentData("999998", "Mumbai", 2, "John");
		obj2.display1();
	}

}

