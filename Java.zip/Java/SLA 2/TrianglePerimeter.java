
class Triangle {

	private int side1;
	private int side2;
	private int side3;
	
	public int getSide1() {
		return side1;
	}

	public float getPerimeter() {
		return perimeter;
	}

	public void setPerimeter(float perimeter) {
		this.perimeter = perimeter;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	private float semiPerimeter;
	private float perimeter;
	private double area;

	Triangle(int s1, int s2, int s3){
		side1 = s1;
		side2 = s2;
		side3 = s3;
	}
	
	public void calculatePerimeter() {
		perimeter = side1 + side2 + side3;
		setPerimeter(perimeter);
	}
	
	public void calculateArea() {
		semiPerimeter = (getPerimeter()/2);
		area = Math.sqrt((semiPerimeter)*(semiPerimeter-side1)*(semiPerimeter-side2)*(semiPerimeter-side3));
		setArea(area);
	}
	
	public float displayPerimeter() {
		return getPerimeter();
	}
	
	public double displayArea() {
		return getArea();
	}

}

public class TrianglePerimeter{
	public static void main(String [] args) {
		Triangle obj = new Triangle(3,4,5);
		obj.calculatePerimeter();
		obj.calculateArea();
		float Perimeter = obj.displayPerimeter();
		double Area = obj.displayArea();
		System.out.println("The area is: " + Area);
		System.out.println("The Perimeter is: " + Perimeter);
	}
}