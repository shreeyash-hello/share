package com.sla2.neptune;

class Employee2 {
    int salary, hours;

    void getInfo(int sal, int hrs) {
        salary = sal;
        hours = hrs;
    }

    void addSal() {
        if (salary < 500) {
            salary += 10;
        }
    }

    void addWork() {
        if (hours > 6) {
            salary += 5;
        }
    }

    public static void main(String[] args) {
        Employee2 e = new Employee2();
        e.getInfo(450, 7);

        e.addSal();
        e.addWork();

        System.out.println("Final Salary = " + e.salary);
    }
}
