package com.sla2.neptune;

import java.util.Scanner;

class Complex {
    int real, imag;

    void input() {
        try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Enter real part: ");
			real = sc.nextInt();
			System.out.print("Enter imaginary part: ");
			imag = sc.nextInt();
		}
    }

    void add(Complex c1, Complex c2) {
        System.out.println("Sum = " + (c1.real + c2.real) + " + " + (c1.imag + c2.imag) + "i");
    }

    void subtract(Complex c1, Complex c2) {
        System.out.println("Difference = " + (c1.real - c2.real) + " + " + (c1.imag - c2.imag) + "i");
    }

    void multiply(Complex c1, Complex c2) {
        int real = c1.real * c2.real - c1.imag * c2.imag;
        int imag = c1.real * c2.imag + c1.imag * c2.real;
        System.out.println("Product = " + real + " + " + imag + "i");
    }

    public static void main(String[] args) {
        Complex c1 = new Complex();
        Complex c2 = new Complex();
        Complex result = new Complex();

        c1.input();
        c2.input();

        result.add(c1, c2);
        result.subtract(c1, c2);
        result.multiply(c1, c2);
    }
}
