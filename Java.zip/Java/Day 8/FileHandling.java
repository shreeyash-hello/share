import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.day2.GetInput;

public class FileHandling {

	public String accept() {
		System.out.println("Enter Data : ");
		String str =  GetInput.inputString();
		return str;
	}
	
	public void readFromFile() {
		
		try(FileInputStream fileStream = new FileInputStream("D:\\java_b2\\data.txt");) 
		{
			File objFile = new File("D:\\java_b2\\data.txt");
			int size = (int)objFile.length();
			byte [] data = new byte[size];
			fileStream.read(data);

			System.out.println(new String(data));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch(IOException e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public void writeToFile(String data) {
		FileOutputStream fileStream = null;
		try {
			fileStream = new FileOutputStream("D:\\java_b2\\data.txt");
			fileStream.write(data.getBytes());
			System.out.println("File written");
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(fileStream != null) {
					fileStream.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}			
		}
	}
	
	public void decryptData() {
		try(FileInputStream fileStream = new FileInputStream("D:\\java_b2\\data.txt");) 
		{
			
			File objFile = new File("D:\\java_b2\\data.txt");
			int size = (int)objFile.length();
			byte [] data = new byte[size];
			fileStream.read(data);

			for(int i = 0; i < data.length; i++) {
				data[i] = (byte) (data[i] - 10);
				System.out.println(data[i]);
			}
			
			FileOutputStream fileOutputStream = new FileOutputStream("D:\\java_b2\\data.txt");
			fileOutputStream.write(data);
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch(IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void encryptData() {
		try(FileInputStream fileStream = new FileInputStream("D:\\java_b2\\data.txt");) 
		{
			
			File objFile = new File("D:\\java_b2\\data.txt");
			int size = (int)objFile.length();
			byte [] data = new byte[size];
			fileStream.read(data);

			for(int i = 0; i < data.length; i++) {
				data[i] = (byte) (data[i] + 10);
				System.out.println(data[i]);
			}
			
			FileOutputStream fileOutputStream = new FileOutputStream("D:\\java_b2\\data.txt");
			fileOutputStream.write(data);
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch(IOException e) 
		{
			e.printStackTrace();
		}
	}
}
