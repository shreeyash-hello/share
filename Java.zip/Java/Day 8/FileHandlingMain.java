import com.day2.GetInput;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileHandlingMain {

	public static void main(String[] args) {
		
		FileHandling objFileHandle = new FileHandling();
		String data = objFileHandle.accept();

		int choice;
		do {
			System.out.println("--------MENU----------");
			System.out.println("1. Add contents ");
			System.out.println("2. Encrypt File");
			System.out.println("3. Decrypt File");
			System.out.println("4. Exit");
			System.out.println("Enter your choice : ");
			choice = GetInput.getInt();
			switch(choice) {
				case 1 :
				{			
					objFileHandle.writeToFile(data);
					objFileHandle.readFromFile();
				}
				break;
				
				case 2 :
				{																							
					objFileHandle.encryptData();
					objFileHandle.readFromFile();
					
				}
				break;
				
				case 3 :
				{					
					objFileHandle.decryptData();
					objFileHandle.readFromFile();
				}
				break;
				
				case 4 :
				{
					System.out.println("Program Exit!!");
				}
				break;
			}

		}while(choice!=4);
	}
	


}
