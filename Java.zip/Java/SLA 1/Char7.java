public class Char7 {
    public static void main(String[] args) {

        String str = "The quick brown fox jumps";
        String rev = "";

        for(int i = str.length() - 1; i >= 0; i--) {
            rev = rev + str.charAt(i);
        }

        System.out.println("Original: " + str);
        System.out.println("Reversed: " + rev);
    }
}