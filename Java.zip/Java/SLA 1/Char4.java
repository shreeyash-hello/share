public class Char4 {
    public static void main(String[] args) {

        String str = "The quick brown fox jumps over the lazy dog.";

        str = str.toLowerCase();

        for(char ch = 'a'; ch <= 'z'; ch++) {

            int index = -1;

            for(int i = 0; i < str.length(); i++) {
                if(str.charAt(i) == ch) {
                    index = i;
                    break;
                }
            }

            System.out.println(ch + " -> " + index);
        }
    }
}