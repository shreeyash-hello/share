public class Char2 {
    public static void main(String[] args) {
        
        String str1 = "This is Exercise 1";
        String str2 = "This is Exercise 2";

        System.out.println("String 1: " + str1);
        System.out.println("String 2: " + str2);

        int result = compareStrings(str1, str2);

        if (result == 0) {
            System.out.println("\"" + str1 + "\" is equal to \"" + str2 + "\"");
        } else if (result < 0) {
            System.out.println("\"" + str1 + "\" is less than \"" + str2 + "\"");
        } else {
            System.out.println("\"" + str1 + "\" is greater than \"" + str2 + "\"");
        }
    }

    public static int compareStrings(String s1, String s2) {
        int len1 = s1.length();
        int len2 = s2.length();
        int minLen = Math.min(len1, len2);

        for (int i = 0; i < minLen; i++) {
            char c1 = s1.toCharArray()[i];
            char c2 = s2.toCharArray()[i];

            if (c1 != c2) {
                return c1 - c2;
            }
        }
        return len1 - len2;
    }
}