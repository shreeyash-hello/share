public class Char3 {
    public static void main(String[] args) {
        
    	int countStr = 2;
        String str1 = "Python Exercises";
        String str2 = "Python Exercises";

        System.out.println("String 1: " + str1);
        System.out.println("String 2: " + str2);

        int result = compareStrings(str1, str2);
        
        String chars = returnCompareStrings(str1, str2);
        

        if(result == 1) {
        	System.out.println("\"" + str1 + "\" ends with \"" + chars + "\"? " + "true");
        }else {
        	System.out.println("\"" + str1 + "\" ends with \"" + chars + "\"? " + "false");
        }

    }

    public static int compareStrings(String s1, String s2) {

        char c1 = s1.toCharArray()[s1.length()-1];
        char c2 = s1.toCharArray()[s1.length()-2];
        char ch1 = s2.toCharArray()[s2.length()-1];
        char ch2 = s2.toCharArray()[s2.length()-2];
        
        if((c1 == ch1) && (c2 == ch2)) {
        	return 1;
        }else {
        	return 0;
        }
    }
    
    public static String returnCompareStrings(String s1, String s2) {

        char c1 = s1.toCharArray()[s1.length()-1];
        char c2 = s1.toCharArray()[s1.length()-2];
        
        return "" + c1 + c2;
    }
}