
public class SeventhNum {

	public static void main(String[] args) {
		for(int i = 1; i < 201; i += 7) {
			System.out.println(i);
		}
	}
}
