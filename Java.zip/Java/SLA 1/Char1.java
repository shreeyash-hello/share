
public class Char1 {

	public static void main(String[] args) {
		String str = "Java Excercises!";
		
		System.out.println("The character at position 3 is: " + str.charAt(2));

	}

}
