public class Char5 {
    public static void main(String[] args) {

        String str = "The quick brown fox jumps over the lazy dog.";
        String result = "";

        for(int i = 0; i < str.length(); i++) {

            if(i + 2 < str.length() &&
               str.charAt(i) == 'f' &&
               str.charAt(i+1) == 'o' &&
               str.charAt(i+2) == 'x') {

                result = result + "cat";
                i = i + 2;
            } else {
                result = result + str.charAt(i);
            }
        }

        System.out.println("Original: " + str);
        System.out.println("New: " + result);
    }
}